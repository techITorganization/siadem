<?php 
$koneksi = mysqli_connect("localhost", "jevknxmx_rootcib", "cibur4yBHN@2023", "jevknxmx_siadem");

if (mysqli_connect_errno()) {
	echo "koneksi gagal " . mysql_connect_error();
}
 ?>