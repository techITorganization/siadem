<?php
require_once 'vendor/autoload.php';

use PhpOffice\PhpWord\TemplateProcessor;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $cabang = $_POST['cabang'];
    $bidang = $_POST['bidang'];
    $alamat = $_POST['alamat'];
    $alasana1 = $_POST['alasana1'];
    $alasana2 = $_POST['alasana2'];
    $alasana3 = $_POST['alasana3'];
    $alasanb1 = $_POST['alasanb1'];
    $alasanb2 = $_POST['alasanb2'];
    $alasanb3 = $_POST['alasanb3'];
    $alasanb4 = $_POST['alasanb4'];
    $alasanc1 = $_POST['alasanc1'];
    $alasanc2 = $_POST['alasanc2'];
    $alasanc3 = $_POST['alasanc3'];
    $setuju_1 = $_POST['setuju_1'];
    $setuju_2 = $_POST['setuju_2'];
    $setuju_3 = $_POST['setuju_3'];
    $setuju_4 = $_POST['setuju_4'];
    $setuju_5 = $_POST['setuju_5'];
    $setuju_6 = $_POST['setuju_6'];
    $setuju_7 = $_POST['setuju_7'];
    $setuju_8 = $_POST['setuju_8'];
    $setuju_9 = $_POST['setuju_9'];
    $setuju_10 = $_POST['setuju_10'];
    $tanggal = date('d F Y');

    $alasana1 = $setuju_1 == "YA" ? "Saya bersedia komitmen dan mengikuti Menara Doa Pelayan Jemaat di SICC (Sabtu, Minggu ke 1)" : "Saya tidak bersedia mengikuti kegiatan karena $alasana1";
    $alasana2 = $setuju_2 == "YA" ? "Saya bersedia komitmen dan mengikuti Menara Doa Pelayan Jemaat GBI Cibubur Raya (Sabtu, Minggu ke 3)" : "Saya tidak bersedia mengikuti kegiatan karena $alasana2";
    $alasana3 = $setuju_3 == "YA" ? "Saya bersedia komitmen dan mengikuti Menara Doa Cibubur Raya (masuk 1 x dalam 1 bulan)" : "Saya tidak bersedia mengikuti kegiatan karena $alasana3";
    $alasanb1 = $setuju_4 == "YA" ? "Saya bersedia komitmen dan mengikuti kegiatan Kubu Doa / Doa Keliling / Rumah Doa" : "Saya tidak bersedia mengikuti kegiatan karena $alasanb1";
    $alasanb2 = $setuju_5 == "YA" ? "Saya bersedia komitmen dan mengikuti kegiatan COOL" : "Saya tidak bersedia mengikuti kegiatan karena $alasanb2";
    $alasanb3 = $setuju_6 == "YA" ? "Saya bersedia komitmen dan mengikuti kegiatan Mercy Seat (Setiap Minggu sebelum Ibadah Raya)" : "Saya tidak bersedia mengikuti kegiatan karena $alasanb3";
    $alasanb4 = $setuju_7 == "YA" ? "Saya bersedia komitmen dan mengikuti kegiatan Doa Persiapan Ibadah Raya (2x dalam 1 bulan)" : "Saya tidak bersedia mengikuti kegiatan karena $alasanb4";
    $alasanc1 = $setuju_8 == "YA" ? "Saya bersedia komitmen dan mengikuti kegiatan Pelatihan yang diselenggarakan baik Vocal ataupun Instrumen" : "Saya tidak bersedia mengikuti kegiatan karena $alasanc1";
    $alasanc2 = $setuju_9 == "YA" ? "Saya bersedia komitmen dan mengikuti kegiatan Menara doa wajib setiap 1 bulan sekali" : "Saya tidak bersedia mengikuti kegiatan karena $alasanc2";
    $alasanc3 = $setuju_10 == "YA" ? "Saya bersedia komitmen dan mengikuti kegiatan COOL (Jika belum tergabung dalam COOL manapun)" : "Saya tidak bersedia mengikuti kegiatan karena $alasanc3";

    $templateProcessor = new TemplateProcessor('template_surat.docx');

    $templateProcessor->setValue('Nama Lengkap', $nama);
    $templateProcessor->setValue('Cabang', $cabang);
    $templateProcessor->setValue('Bidang', $bidang);
    $templateProcessor->setValue('Alamat', $alamat);
    $templateProcessor->setValue('Alasan a1', $alasana1);
    $templateProcessor->setValue('Alasan a2', $alasana2);
    $templateProcessor->setValue('Alasan a3', $alasana3);
    $templateProcessor->setValue('Alasan b1', $alasanb1);
    $templateProcessor->setValue('Alasan b2', $alasanb2);
    $templateProcessor->setValue('Alasan b3', $alasanb3);
    $templateProcessor->setValue('Alasan b4', $alasanb4);
    $templateProcessor->setValue('Alasan c1', $alasanc1);
    $templateProcessor->setValue('Alasan c2', $alasanc2);
    $templateProcessor->setValue('Alasan c3', $alasanc3);
    $templateProcessor->setValue('Setuju 1', $setuju_1);
    $templateProcessor->setValue('Setuju 2', $setuju_2);
    $templateProcessor->setValue('Setuju 3', $setuju_3);
    $templateProcessor->setValue('Setuju 4', $setuju_4);
    $templateProcessor->setValue('Setuju 5', $setuju_5);
    $templateProcessor->setValue('Setuju 6', $setuju_6);
    $templateProcessor->setValue('Setuju 7', $setuju_7);
    $templateProcessor->setValue('Setuju 8', $setuju_8);
    $templateProcessor->setValue('Setuju 9', $setuju_9);
    $templateProcessor->setValue('Setuju 10', $setuju_10);
    $templateProcessor->setValue('Tanggal', $tanggal);

    $filename = 'Surat_Pernyataan_' . $nama . '.docx';
    $templateProcessor->saveAs($filename);

    header('Content-Description: File Transfer');
    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Disposition: attachment; filename=' . basename($filename));
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($filename));
    flush();
    readfile($filename);
    unlink($filename);
    exit;
}
?>
